import Layout from "../components/Layout"
import Home from "../pages/Home"
import React from 'react';
export default function page() {
  return (
      <>
        <Home></Home>
      </>
  )
}
